import React from 'react';
import TempApp from './Components/weather/TempApp';

function App() {
  return (
    <div>
    <TempApp />
    </div>
  );
}

export default App;

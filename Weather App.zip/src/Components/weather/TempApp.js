import React ,{useState , useEffect} from 'react';
import {BiStreetView} from 'react-icons/bi'
import '../Css/Style.css';

const TempApp = () => {
    // Using useState
    const [city , setCity] = useState(null);
    const [search ,setSearch] = useState('Lahore');
       // using useEffect 
    useEffect( () => {
        const fetchapi = async() => {
            // Fetching Api From Url
            const url = `https://api.openweathermap.org/data/2.5/weather?q=${search}&units=metric&appid=dc12cfa49e4fd09b463bf35574baea12`; 
            const response = await fetch(url)
            const resJson = await response.json();
            // console.log(resJson);
            setCity(resJson.main);
        };
        fetchapi();
    },[search] )
  return (
    <>
      <div className='box'>
      {/* Search Field */}
      <div className='inputData'>
      <input
      type='search'
      className='inputField'
      onChange={(event)=> (
        setSearch(event.target.value)
      )}
       />
      </div>
      {/* using ternery operator */}
      {!city ? (
        <p className='error'>No City Found</p>
      ):(
      <>
      <div className='info'>
      <h2 className='location'>
      {/* react Icon */}
        <BiStreetView size={50} className='fa-street-view'/>
        {search}
      </h2> 
      <h1 className='temp'>
      {/* Temp details */}
      {city.temp}°Cel
      </h1>
      <h3 className='tempmin_max'>
      {/* Min Max */}
        Min : {city.temp_min}°Cel | Max : {city.temp_max}°Cel
      </h3>
      </div>
      {/* bg Effect */}
      <div className='wave'></div>
      <div className='wave.-three'></div>
      <div className='wave.-two'></div>
      </>
    )}
      </div>
    </>
  )
}

export default TempApp
